---
title: Bezier2
categories:
  - Graphics
tags:
  - graphics
  - vector
  - pen
---
