---
title: Building
categories:
  - People
tags:
  - company
  - enterprise
  - organization
  - office
  - business
---
