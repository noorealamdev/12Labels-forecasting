---
title: Caret down
categories:
  - Carets
tags:
  - caret
  - arrow
  - triangle
---
