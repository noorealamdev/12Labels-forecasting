<?php return array (
  'call-apis' => 'App\\Http\\Livewire\\CallApis',
);